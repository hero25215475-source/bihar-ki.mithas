# Bihar Ki Mithash – Static Site (Free Domain Ready)

This is a **static, single-page shop** for Bihar famous foods with photos (via Unsplash Source), cart, and a demo checkout (opens an email draft).

## Quick Deploy (Free)

### Option A: GitHub Pages (Recommended)
1. Create a new GitHub repository, e.g. `bihar-ki-mithash`.
2. Upload the files from this folder.
3. Go to **Settings → Pages → Branch: `main` / root** → Save.
4. Your site will be live at: `https://<your-username>.github.io/bihar-ki-mithash/`

### (Optional) Custom or Free Domain
- Add a custom domain in **Pages → Custom domain** and follow DNS instructions.
- You can also use a free domain from Freenom (.tk, .ml, etc.) and CNAME it to the GitHub Pages URL.

## Features
- Tailwind via CDN (no build step)
- Product photos auto-fetched from Unsplash Source using keywords
- Cart with localStorage
- Checkout opens `mailto:` with order details
- Fully client-side; no backend required

## Editing Products
Open `index.html`, find the `PRODUCTS` array (near the bottom `<script>`). Update names, prices, and images.
